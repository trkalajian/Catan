import numpy as np
import random
import torch
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue
from stable_baselines3.common.vec_env.base_vec_env import CloudpickleWrapper

def _worker(manager_fn_wrapper: CloudpickleWrapper):
    torch.set_num_threads(1)
    evaluation_manager = manager_fn_wrapper.var()

    while True:
        try:
            cmd, data = remote_queue.get()
            if cmd == "run_eval_episodes":
                num_episodes = data
                winners = []
                num_game_steps = []
                victory_points_all = []
                policy_steps = []
                for ep in range(num_episodes):
                    winner, victory_points, total_steps, policy_decisions = evaluation_manager.run_evaluation_game()
                    winners.append(winner)
                    num_game_steps.append(total_steps)
                    victory_points_all.append(victory_points)
                    policy_steps.append(policy_decisions)
                result_queue.put((winners, num_game_steps, victory_points_all, policy_steps))
            elif cmd == "update_policies":
                state_dicts = data.var
                evaluation_manager._update_policies(state_dicts)
                result_queue.put(True)
        except EOFError:
            break

class SubProcEvaluationManager(object):

    def __init__(self, evaluation_manager_fns, n_threads=None):
        self.waiting = False
        self.closed = False
        self.remote_queue = Queue()
        self.result_queue = Queue()
        self.executor = ThreadPoolExecutor(max_workers=n_threads)

        for evaluation_manager_fn in evaluation_manager_fns:
            self.executor.submit(_worker, CloudpickleWrapper(evaluation_manager_fn))

    def run_evaluation_episodes_async(self, total_episodes):
        eps_per_process = total_episodes // self.executor._max_workers
        for _ in range(self.executor._max_workers):
            self.remote_queue.put(("run_eval_episodes", eps_per_process))
        self.waiting = True

    def run_evaluation_episodes_wait(self):
        results = [self.result_queue.get() for _ in range(self.executor._max_workers)]
        self.waiting = False
        return results

    def run_evaluation_episodes(self, total_episodes):
        self.run_evaluation_episodes_async(total_episodes)
        return self.run_evaluation_episodes_wait()

    def update_policies(self, state_dicts):
        for _ in range(self.executor._max_workers):
            self.remote_queue.put(("update_policies", CloudpickleWrapper(state_dicts)))
        results = [self.result_queue.get() for _ in range(self.executor._max_workers)]
        return results

    def close(self) -> None:
        if self.closed:
            return
        if self.waiting:
            for _ in range(self.executor._max_workers):
                self.result_queue.get()
        self.executor.shutdown(wait=False)
        self.closed = True
