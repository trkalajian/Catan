from setuptools import setup
import setuptools

setup(name='SettlersRL',
      version='1.0.0',
      description='Settlers of Catan RL Environment/Training with PPO',
      author='Henry Charlesworth',
      packages=setuptools.find_packages(),
      zip_safe=False)
